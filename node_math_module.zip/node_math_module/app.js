var math_module = require('./mathlib');
math_module.add(5,6);
math_module.multiply(5,6);
math_module.square(5);
